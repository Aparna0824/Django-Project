from django.urls import path
from .views import register, login, home, submit_course,edit_course,delete_course

urlpatterns = [
    path('', register, name='register'),
    path('login/', login, name='login'),
    path('home/', home, name='home'),
    path('submit_course/', submit_course, name='submit_course'),
    path('edit_course/<int:course_id>', edit_course, name='edit_course'),
    path('delete_course/<int:course_id>', delete_course, name='delete_course'),
]
