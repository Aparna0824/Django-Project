from urllib import request
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Course, UserProfile
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        contact = request.POST['contact']
        password = request.POST['password']

        # Check if a user with the same username or email already exists
        if User.objects.filter(username=username).exists() or User.objects.filter(email=email).exists():
            messages.error(request, 'A user with this username or email already exists.')
            return redirect('register')

        # If no existing user found, create a new one
        UserProfile.objects.create(username=username, email=email, contact=contact, password=password)
        messages.success(request, 'Successfully registered!')
        return redirect('login')

    return render(request, 'register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = UserProfile.objects.filter(username=username, password=password).first()

        if user:
            # Set the username in the session
            request.session['username'] = username
            messages.success(request, 'Successfully logged in!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'login.html')

def home(request):
    username = request.session.get('username')

    # Retrieve all courses from the database
    courses = Course.objects.all()

    return render(request, 'home.html', {'username': username, 'courses': courses})


def submit_course(request):
    if request.method == 'POST':
        course_title = request.POST.get('course_title')
        course_description = request.POST.get('course_description')
        course_duration = request.POST.get('course_duration')

        Course.objects.create(
            title=course_title,
            description=course_description,
            duration=course_duration
        )

        messages.success(request, 'Course submitted successfully!')
        return redirect('home')

    messages.error(request, 'Invalid form submission.')
    return redirect('home')


def edit_course(request, course_id):
    course = get_object_or_404(Course, pk=course_id)

    if request.method == 'POST':
        course_title = request.POST.get('course_title')
        course_description = request.POST.get('course_description')
        course_duration = request.POST.get('course_duration')

        course.title = course_title
        course.description = course_description
        course.duration = course_duration
        course.save()

        messages.success(request, 'Course updated successfully!')
        return redirect('home')
    
    
    return render(request, 'edit_course.html', {'course': course})

def delete_course(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    if request.method == 'POST':
        course.delete()
        messages.success(request, 'Course deleted successfully!')
        return redirect('home')
    return render(request, 'delete_course.html', {'course': course})


